Installation
--------------
  
  ```
  $ (env) pip install -r requirements.txt
  $ (env) python manage.py makemigrations
  $ (env) python manage.py migrate
  $ (env) python manage.py collectstatic
  $ (env) python manage.py createsuperuser
  $ (env) python manage.py loaddata fixtures/*
  $ (env) python manage.py runserver
  ```
  
Run
--------------

```
http://localhost:8000
```


